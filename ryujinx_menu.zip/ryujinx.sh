#!/bin/bash
# Ryujinx Menu Script

REPO_OWNER="Ryujinx"
REPO_NAME="release-channel-master"

# Fetch the latest tag from GitHub API
latest_tag=$(curl -s https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/releases/latest | grep '"tag_name":' | sed -E 's/.*"([^"]+)".*/\1/')

RYU_URL="https://github.com/$REPO_OWNER/$REPO_NAME/releases/download/$latest_tag/ryujinx-$latest_tag-linux_arm64.tar.gz"
RYU_ARCHIVE="ryujinx-$latest_tag-linux_arm64.tar.gz"

update_mesa() {
    run_proot apt update -y && \
    run_proot apt install -y software-properties-common && \
    run_proot add-apt-repository -y "ppa:mastag/mesa-turnip-kgsl" && \
    run_proot apt update -y && \
    run_proot apt dist-upgrade -y || \
    err "Failed to update Mesa"
}

err() {
    echo -e "\033[1;31mError: $@\033[0m" >&2
    exit 1
}

install_ryu() {
    cat > $HOME/.profile <<EOF
export DISPLAY=:0
export DOTNET_GCHeapHardLimit=1C0000000
export MESA_LOADER_DRIVER_OVERRIDE=zink
export TU_DEBUG=noconform
EOF
    cat > $PREFIX/bin/ryujinx <<EOF
#!/data/data/com.termux/files/usr/bin/bash
termux-x11 :0 &>/dev/null & sleep 1
proot-distro login --shared-tmp --isolated --bind /sdcard --termux-home ubuntu -- /root/publish/Ryujinx
# kill x11
pkill -9 "app_process"
EOF
    chmod +x $PREFIX/bin/ryujinx
}

update_ryujinx() {
    echo "Updating Ryujinx..."
    wget "$RYU_URL" -O "$RYU_ARCHIVE" || err "Failed to download Ryujinx"
        tar -xzf "$RYU_ARCHIVE" && rm "$RYU_ARCHIVE" || err "Failed to extract Ryujinx"
    install_ryu
    echo "Ryujinx has been successfully updated to $latest_tag!"
}

run_proot() {
    proot-distro login --termux-home --isolated ubuntu -- "$@" || err "Proot command failed: $@"
}


echo "Welcome to Ryujinx!"
while true; do
    echo "1. Start Emulator"
    echo "2. Update Ryujinx"
    echo "3. Update Mesa"
    echo "4. Exit"
    echo -n "Choose an option: "
    read choice
    case $choice in
        1)
            echo "Starting Ryujinx Emulator..."
            am start -n com.termux.x11/com.termux.x11.MainActivity
            ryujinx
            ;;
        2)
            echo "Updating Ryujinx..."
            update_ryujinx
            ;;
        3)
           update_mesa
           ;;
        4)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid option, please try again."
            ;;
    esac
done
