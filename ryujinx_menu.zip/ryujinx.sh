#!/bin/bash
# Ryujinx Menu Script

echo "Welcome to Ryujinx!"
while true; do
    echo "1. Start Emulator"
    echo "2. Update Ryujinx"
    echo "3. Exit"
    echo -n "Choose an option: "
    read choice
    case $choice in
        1)
            echo "Starting Ryujinx Emulator..."
            ryujinx
            ;;
        2)
            echo "Updating Ryujinx..."
            echo "Not Implemented"
            ;;
        3)
            echo "Exiting..."
            exit 0
            ;;
        *)
            echo "Invalid option, please try again."
            ;;
    esac
done
